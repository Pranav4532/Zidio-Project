import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from "./comp/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import PostJob from "./pages/PostJob";
import JobList from "./pages/JobList";
import UploadResume from "./pages/UploadResume";

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/jobs" element={<JobList />} />
        <Route path="/post-job" element={<PostJob />} />
        <Route path="/upload" element={<UploadResume />} />
      </Routes>
    </Router>
  );
}

export default App;
