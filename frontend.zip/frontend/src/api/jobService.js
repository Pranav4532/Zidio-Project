import axios from "axios";

const API_URL = "http://localhost:6060/api/upload";

export const uploadResume = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return axios.post(`${API_URL}/resume`, formData);
};

export const uploadImage = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return axios.post(`${API_URL}/image`, formData);
};
