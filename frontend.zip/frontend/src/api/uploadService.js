import axios from "axios";

const API_URL = "http://localhost:6060/api/upload";

export const uploadResume = async (file) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await axios.post(`${API_URL}/resume`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return response.data;
};

export const uploadCertificate = async (file) => {
  const formData = new FormData();
  formData.append("file", file);

  const response = await axios.post(`${API_URL}/image`, formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return response.data;
};
