import { useState } from "react";
import axios from "axios";

function UploadResume() {
  const [file, setFile] = useState(null);

  const handleFileChange = (e) => setFile(e.target.files[0]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) {
      alert("Please select a file!");
      return;
    }
    const formData = new FormData();
    formData.append("resume", file);

    try {
      const res = await axios.post("http://localhost:8080/api/resume/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      console.log("Resume Uploaded:", res.data);
      alert("Resume uploaded successfully!");
    } catch (err) {
      console.error(err);
      alert("Upload failed!");
    }
  };

  return (
    <div>
      <h2>Upload Resume</h2>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} accept=".pdf,.doc,.docx" />
        <br />
        <button type="submit">Upload</button>
      </form>
    </div>
  );
}

export default UploadResume;
