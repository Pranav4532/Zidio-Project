import { useEffect, useState } from "react";
import axios from "axios";

function JobList() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:8080/api/jobs")
      .then((res) => setJobs(res.data))
      .catch((err) => console.error("Error loading jobs:", err));
  }, []);

  return (
    <div>
      <h2>Available Jobs</h2>
      <ul>
        {jobs.map((job) => (
          <li key={job.id}>
            <strong>{job.title}</strong> - {job.description}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default JobList;
