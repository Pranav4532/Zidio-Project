import { useState } from "react";
import axios from "axios";

function PostJob() {
  const [form, setForm] = useState({ title: "", description: "" });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:8080/api/jobs", form);
      console.log("Job Posted:", res.data);
      alert("Job posted successfully!");
    } catch (err) {
      console.error(err);
      alert("Failed to post job!");
    }
  };

  return (
    <div>
      <h2>Post a Job</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="title" placeholder="Job Title"
          value={form.title} onChange={handleChange} required />
        <br />
        <textarea name="description" placeholder="Job Description"
          value={form.description} onChange={handleChange} required />
        <br />
        <button type="submit">Post Job</button>
      </form>
    </div>
  );
}

export default PostJob;
