function Home() {
  return (
    <div>
      <h1>Welcome to Job Portal</h1>
      <p>Find jobs, post jobs, and upload resumes.</p>
    </div>
  );
}

export default Home;
