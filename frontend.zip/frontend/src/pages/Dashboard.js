function Dashboard() {
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Welcome to your dashboard! Here you can manage jobs and resumes.</p>
    </div>
  );
}

export default Dashboard;
