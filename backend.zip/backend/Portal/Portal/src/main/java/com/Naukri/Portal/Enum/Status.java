package com.Naukri.Portal.Enum;

public enum Status {
APPLIED,SHORTLISTED,REJECTED
}
