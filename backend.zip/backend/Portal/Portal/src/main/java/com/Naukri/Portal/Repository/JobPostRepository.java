package com.Naukri.Portal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Naukri.Portal.Entity.JobPost;
import com.Naukri.Portal.Enum.JobType;

@Repository
public interface JobPostRepository extends JpaRepository<JobPost, Long> {
    List<JobPost> getByCompanyName(String companyName);
    List<JobPost> getByRecruiterEmail(String recruiterEmail);
    List<JobPost> getByJobTitle(String jobTitle);
    List<JobPost> getByJobType(JobType jobType);
    List<JobPost> getByJobLocation(String location);
}
