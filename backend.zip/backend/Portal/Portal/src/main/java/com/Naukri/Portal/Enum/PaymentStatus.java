package com.Naukri.Portal.Enum;

public enum PaymentStatus {
	SUCCESS, FAILED, PENDING
}
