package com.Naukri.Portal.Enum;

public enum PlanName {
	 FREE, BASIC, PREMIUM
}
