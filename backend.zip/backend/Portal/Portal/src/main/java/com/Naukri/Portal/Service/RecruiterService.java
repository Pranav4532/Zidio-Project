package com.Naukri.Portal.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Naukri.Portal.DTO.RecruiterDTO;
import com.Naukri.Portal.Entity.Recruiter;
import com.Naukri.Portal.Repository.RecruiterRepository;

@Service
public class RecruiterService {
    
    @Autowired
    private RecruiterRepository recruiterRepository;

    public Recruiter createRecruiterProfile(RecruiterDTO dto) {
        Recruiter recruiter = new Recruiter();
        recruiter.setRecruiterEmail(dto.getRecruiterEmail());
        recruiter.setRecruiterPhone(dto.getRecruiterPhone());
        recruiter.setCompanyName(dto.getCompanyName());
        recruiter.setCompanyWebsite(dto.getCompanyWebsite());
        return recruiterRepository.save(recruiter);
    }

    public Recruiter getRecruiterById(Long id) {
        return recruiterRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Recruiter not found with id: " + id));
    }

    public Recruiter getRecruiterByEmail(String email) {
        return recruiterRepository.findByRecruiterEmail(email)
                .orElseThrow(() -> new RuntimeException("Recruiter not found with email: " + email));
    }
}
