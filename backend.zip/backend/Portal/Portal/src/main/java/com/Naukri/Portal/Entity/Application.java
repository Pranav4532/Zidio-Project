package com.Naukri.Portal.Entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.Naukri.Portal.Enum.JobType;
import com.Naukri.Portal.Enum.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name ="applications")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Application {
 
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String jobSeekerName;
	@Column(unique = true)
	private String jobSeekerEmail;
	private Long jobId;
	private String jobTitle;
	private JobType jobType;
	@Column(unique = true)
	private String recruiterEmail;
	private Status status;
	private LocalDateTime appliedAt;
	
}
