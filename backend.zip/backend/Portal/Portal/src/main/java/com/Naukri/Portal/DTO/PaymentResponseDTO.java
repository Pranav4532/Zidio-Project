package com.Naukri.Portal.DTO;


import com.Naukri.Portal.Enum.PaymentStatus;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentResponseDTO {
    private String transactionId;
    private PaymentStatus paymentStatus;
    private Double amount;
}

