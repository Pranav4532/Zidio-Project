package com.Naukri.Portal.Entity;


import javax.persistence.*;

import com.Naukri.Portal.Enum.Duration;
import com.Naukri.Portal.Enum.PlanName;

import lombok.*;

@Entity
@Table(name="plans")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SubscriptionPlan {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private PlanName planName;

    private Double price;
    private String currency;

    @Enumerated(EnumType.STRING)
    private Duration duration;

    private String features;
}

