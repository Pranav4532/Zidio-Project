package com.Naukri.Portal.Enum;

public enum Action {
BLOCK,UNBLOCK
}
