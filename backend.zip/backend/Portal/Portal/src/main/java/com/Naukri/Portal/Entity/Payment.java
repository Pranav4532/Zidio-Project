package com.Naukri.Portal.Entity;


import java.time.LocalDateTime;
import javax.persistence.*;

import com.Naukri.Portal.Enum.PaymentStatus;

import lombok.*;

@Entity
@Table(name="payment")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Payment {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long planId;
    private Double amount;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;

    private String transactionId;
    private LocalDateTime timeStamp;
}

