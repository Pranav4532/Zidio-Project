package com.Naukri.Portal.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Naukri.Portal.DTO.JobPostDTO;
import com.Naukri.Portal.Entity.JobPost;
import com.Naukri.Portal.Enum.JobType;
import com.Naukri.Portal.Repository.JobPostRepository;

@Service
public class JobPostService {

    @Autowired
    private JobPostRepository jobPostRepository;

    public JobPostDTO createJob(JobPostDTO dto) {
        JobPost job = new JobPost();
        job.setCompanyName(dto.getCompanyName());
        job.setJobTitle(dto.getJobTitle());
        job.setRecruiterEmail(dto.getRecruiterEmail());
        job.setJobCategory(dto.getJobCategory());
        job.setJobDescription(dto.getJobDescription());
        job.setJobType(dto.getJobType());
        job.setJobLocation(dto.getJobLocation());
        job.setRemote(dto.isRemote());
        job.setPostedDate(dto.getPostedDate());

        JobPost saved = jobPostRepository.save(job);
        return mapToDTO(saved);
    }

    public List<JobPostDTO> getAllJobs() {
        return jobPostRepository.findAll()
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<JobPostDTO> getJobByCompanyName(String companyName) {
        return jobPostRepository.getByCompanyName(companyName)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<JobPostDTO> getJobByRecruiterEmail(String recruiterEmail) {
        return jobPostRepository.getByRecruiterEmail(recruiterEmail)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<JobPostDTO> getJobByJobTitle(String jobTitle) {
        return jobPostRepository.getByJobTitle(jobTitle)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<JobPostDTO> getJobByJobType(JobType jobType) {
        return jobPostRepository.getByJobType(jobType)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public List<JobPostDTO> getJobByLocation(String location) {
        return jobPostRepository.getByJobLocation(location)
                .stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public JobPostDTO getJobById(Long id) {
        JobPost job = jobPostRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found with id: " + id));
        return mapToDTO(job);
    }

    public JobPostDTO updateJob(Long id, JobPostDTO dto) {
        JobPost job = jobPostRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found with id: " + id));

        job.setCompanyName(dto.getCompanyName());
        job.setJobTitle(dto.getJobTitle());
        job.setRecruiterEmail(dto.getRecruiterEmail());
        job.setJobCategory(dto.getJobCategory());
        job.setJobDescription(dto.getJobDescription());
        job.setJobType(dto.getJobType());
        job.setJobLocation(dto.getJobLocation());
        job.setRemote(dto.isRemote());
        job.setPostedDate(dto.getPostedDate());

        JobPost updated = jobPostRepository.save(job);
        return mapToDTO(updated);
    }

    public void deleteJob(Long id) {
        if (!jobPostRepository.existsById(id)) {
            throw new RuntimeException("Job not found with id: " + id);
        }
        jobPostRepository.deleteById(id);
    }

    private JobPostDTO mapToDTO(JobPost post) {
        JobPostDTO dto = new JobPostDTO();
        dto.setId(post.getId());
        dto.setCompanyName(post.getCompanyName());
        dto.setRecruiterEmail(post.getRecruiterEmail());
        dto.setJobCategory(post.getJobCategory());
        dto.setJobDescription(post.getJobDescription());
        dto.setJobTitle(post.getJobTitle());
        dto.setJobType(post.getJobType());
        dto.setJobLocation(post.getJobLocation());
        dto.setPostedDate(post.getPostedDate());
        dto.setRemote(post.isRemote());
        return dto;
    }
}
