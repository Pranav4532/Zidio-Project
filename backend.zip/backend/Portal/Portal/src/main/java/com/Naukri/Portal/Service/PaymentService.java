package com.Naukri.Portal.Service;


import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.Naukri.Portal.DTO.PaymentRequestDTO;
import com.Naukri.Portal.DTO.PaymentResponseDTO;
import com.Naukri.Portal.Entity.Payment;
import com.Naukri.Portal.Enum.PaymentStatus;
import com.Naukri.Portal.Repository.PaymentRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepo;

    public PaymentResponseDTO processPayment(PaymentRequestDTO dto) {
        Payment pay = Payment.builder()
                .userId(dto.getUserId())
                .planId(dto.getPlanId())
                .amount(dto.getAmount())
                .paymentStatus(PaymentStatus.SUCCESS)
                .transactionId(UUID.randomUUID().toString())
                .timeStamp(LocalDateTime.now())
                .build();

        paymentRepo.save(pay);

        return PaymentResponseDTO.builder()
                .transactionId(pay.getTransactionId())
                .paymentStatus(pay.getPaymentStatus())
                .amount(pay.getAmount())
                .build();
    }
}

