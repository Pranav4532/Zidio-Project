package com.Naukri.Portal.DTO;


import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentRequestDTO {
    private Long userId;
    private Long planId;
    private Double amount;
}

