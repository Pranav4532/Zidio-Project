package com.Naukri.Portal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Naukri.Portal.DTO.JobPostDTO;
import com.Naukri.Portal.Enum.JobType;
import com.Naukri.Portal.Service.JobPostService;

@RestController
@RequestMapping("/api/jobPost")
public class JobPostController {

    @Autowired
    private JobPostService jobPostService;

    @PostMapping
    public ResponseEntity<JobPostDTO> createJobPost(@RequestBody JobPostDTO dto) {
        return ResponseEntity.ok(jobPostService.createJob(dto));
    }

    @GetMapping("/all")
    public ResponseEntity<List<JobPostDTO>> getAllJobs() {
        return ResponseEntity.ok(jobPostService.getAllJobs());
    }

    @GetMapping("/postedBy")
    public ResponseEntity<List<JobPostDTO>> getJobsByRecruiter(@PathVariable String recruiterEmail) {
        return ResponseEntity.ok(jobPostService.getJobByRecruiterEmail(recruiterEmail));
    }

    @GetMapping("/search/{companyName}")
    public ResponseEntity<List<JobPostDTO>> getJobsByCompanyName(@PathVariable String companyName) {
        return ResponseEntity.ok(jobPostService.getJobByCompanyName(companyName));
    }

    @GetMapping("/search/{jobTitle}")
    public ResponseEntity<List<JobPostDTO>> getJobsByJobTitle(@PathVariable String jobTitle) {
        return ResponseEntity.ok(jobPostService.getJobByJobTitle(jobTitle));
    }

    @GetMapping("/search/{jobType}")
    public ResponseEntity<List<JobPostDTO>> getJobsByJobType(@PathVariable JobType jobType) {
        return ResponseEntity.ok(jobPostService.getJobByJobType(jobType));
    }

    @GetMapping("/search/{location}")
    public ResponseEntity<List<JobPostDTO>> getJobsByLocation(@PathVariable String location) {
        return ResponseEntity.ok(jobPostService.getJobByLocation(location));
    }

    @GetMapping("/{id}")
    public ResponseEntity<JobPostDTO> getJobById(@PathVariable Long id) {
        return ResponseEntity.ok(jobPostService.getJobById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<JobPostDTO> updateJobPost(@PathVariable Long id, @RequestBody JobPostDTO dto) {
        return ResponseEntity.ok(jobPostService.updateJob(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteJobPost(@PathVariable Long id) {
        jobPostService.deleteJob(id);
        return ResponseEntity.ok("Job deleted successfully");
    }
}
