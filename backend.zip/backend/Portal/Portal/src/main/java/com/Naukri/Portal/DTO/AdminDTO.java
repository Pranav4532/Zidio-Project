package com.Naukri.Portal.DTO;

import com.Naukri.Portal.Enum.Action;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdminDTO {

	private Long adminId;
	private Long userId;
	
	private Action action;
}
