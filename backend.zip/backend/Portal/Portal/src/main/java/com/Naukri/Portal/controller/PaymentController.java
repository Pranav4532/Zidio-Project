package com.Naukri.Portal.controller;


import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Naukri.Portal.DTO.PaymentRequestDTO;
import com.Naukri.Portal.DTO.PaymentResponseDTO;
import com.Naukri.Portal.Entity.Payment;
import com.Naukri.Portal.Entity.SubscriptionPlan;
import com.Naukri.Portal.Repository.PaymentRepository;
import com.Naukri.Portal.Repository.SubscriptionPlanRepository;
import com.Naukri.Portal.Service.InvoiceService;
import com.Naukri.Portal.Service.PaymentService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/payment")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;
    private final SubscriptionPlanRepository subPlanRepo;
    private final PaymentRepository paymentRepo;
    private final InvoiceService invoiceService;

    @PostMapping("/process")
    public ResponseEntity<PaymentResponseDTO> process(@RequestBody PaymentRequestDTO dto) {
        return ResponseEntity.ok(paymentService.processPayment(dto));
    }

    @GetMapping("/plans")
    public ResponseEntity<List<SubscriptionPlan>> getPlans() {
        return ResponseEntity.ok(subPlanRepo.findAll());
    }

    @PostMapping("/plans")
    public ResponseEntity<SubscriptionPlan> createPlans(@RequestBody SubscriptionPlan plan) {
        return ResponseEntity.ok(subPlanRepo.save(plan));
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<Payment>> history(@PathVariable Long userId) {
        return ResponseEntity.ok(paymentRepo.findByUserId(userId));
    }

    @GetMapping("/invoice/{paymentId}")
    public ResponseEntity<byte[]> downloadInvoice(@PathVariable Long paymentId) {
        Payment pay = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
        byte[] pdfBytes = invoiceService.generateInvoice(pay);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=Invoice-" + pay.getTransactionId() + ".pdf")
                .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}

