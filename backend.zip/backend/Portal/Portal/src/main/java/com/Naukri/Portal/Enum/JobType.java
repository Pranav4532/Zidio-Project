package com.Naukri.Portal.Enum;

public enum JobType {
    FULL_TIME,
    PART_TIME,
    INTERNSHIP,
    CONTRACT,
    TEMPORARY,
    FREELANCE,
    REMOTE,
    VOLUNTEER
}
