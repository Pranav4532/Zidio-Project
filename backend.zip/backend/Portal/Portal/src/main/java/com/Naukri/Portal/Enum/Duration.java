package com.Naukri.Portal.Enum;

public enum Duration {
	 MONTHLY, QUARTERLY, YEARLY
}
