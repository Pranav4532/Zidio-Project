package com.Naukri.Portal.Enum;

public enum Role {
JOBSEEKER,RECRUITER,ADMIN
}
