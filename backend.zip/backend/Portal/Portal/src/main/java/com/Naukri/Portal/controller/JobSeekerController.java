package com.Naukri.Portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Naukri.Portal.DTO.JobSeekerDTO;
import com.Naukri.Portal.Service.JobSeekerService;

@RestController
@RequestMapping("/api/jobSeekers")
public class JobSeekerController {

	@Autowired
	private JobSeekerService jobSeekerService;

	@PostMapping
	public ResponseEntity<JobSeekerDTO> saveJobSeeker(@RequestBody JobSeekerDTO dto) {
		return ResponseEntity.ok(jobSeekerService.createOrUpdate(dto));
	}

	@GetMapping("/{email}")
	public ResponseEntity<JobSeekerDTO> getJobSeekerByEmail(@PathVariable String email) {
		JobSeekerDTO dto = jobSeekerService.getJobSeekerByEmail(email);
		if (dto == null) {
			return ResponseEntity.notFound().build();
		}
		return ResponseEntity.ok(dto);
	}
}
