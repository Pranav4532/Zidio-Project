package com.Naukri.Portal.Service;


import java.io.ByteArrayOutputStream;
import org.springframework.stereotype.Service;

import com.Naukri.Portal.Entity.Payment;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class InvoiceService {

    public byte[] generateInvoice(Payment pay) {
        try {
            Document doc = new Document();
            ByteArrayOutputStream baops = new ByteArrayOutputStream();
            PdfWriter.getInstance(doc, baops);
            doc.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Paragraph title = new Paragraph("Payment Invoice", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            doc.add(title);

            doc.add(new Paragraph(""));
            doc.add(new Paragraph("Invoice ID: " + pay.getTransactionId()));
            doc.add(new Paragraph("User ID: " + pay.getUserId()));
            doc.add(new Paragraph("Plan ID: " + pay.getPlanId()));
            doc.add(new Paragraph("Amount Paid: Rs " + pay.getAmount()));
            doc.add(new Paragraph("Payment Status: " + pay.getPaymentStatus()));
            doc.add(new Paragraph("Date: " + pay.getTimeStamp()));

            doc.add(new Paragraph(""));
            doc.add(new Paragraph("Thank you for using our platform."));

            doc.close();
            return baops.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Error generating invoice", e);
        }
    }
}

