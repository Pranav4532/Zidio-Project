package com.Naukri.Portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.Naukri.Portal.DTO.RecruiterDTO;
import com.Naukri.Portal.Entity.Recruiter;
import com.Naukri.Portal.Service.RecruiterService;

@RestController
@RequestMapping("/api/recruiters")
public class RecruiterController {
    
    @Autowired
    private RecruiterService recruiterService;

    @PostMapping("/profile")
    public ResponseEntity<Recruiter> createRecruiterProfile(@RequestBody RecruiterDTO dto) {
        return ResponseEntity.ok(recruiterService.createRecruiterProfile(dto));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Recruiter> getRecruiterById(@PathVariable Long id) {
        return ResponseEntity.ok(recruiterService.getRecruiterById(id));
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<Recruiter> getRecruiterByEmail(@PathVariable String email) {
        return ResponseEntity.ok(recruiterService.getRecruiterByEmail(email));
    }
}
