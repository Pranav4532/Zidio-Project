package com.Naukri.Portal.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Naukri.Portal.DTO.JobSeekerDTO;
import com.Naukri.Portal.Entity.JobSeeker;
import com.Naukri.Portal.Repository.JobSeekerRepository;

@Service
public class JobSeekerService {

	@Autowired
	private JobSeekerRepository jobSeekerRepository;

	public JobSeekerDTO createOrUpdate(JobSeekerDTO dto) {
		JobSeeker jobSeek = new JobSeeker();

		jobSeek.setId(dto.getId());
		jobSeek.setName(dto.getName());
		jobSeek.setEmail(dto.getEmail());
		jobSeek.setPhone(dto.getPhone());
		jobSeek.setUniversityName(dto.getUniversityName());
		jobSeek.setCourse(dto.getCourse());
		jobSeek.setPassingYear(dto.getPassingYear());
		jobSeek.setResumeURL(dto.getResumeURL());

		JobSeeker saved = jobSeekerRepository.save(jobSeek);

		JobSeekerDTO result = new JobSeekerDTO();
		result.setId(saved.getId());
		result.setName(saved.getName());
		result.setEmail(saved.getEmail());
		result.setPhone(saved.getPhone());
		result.setUniversityName(saved.getUniversityName());
		result.setCourse(saved.getCourse());
		result.setPassingYear(saved.getPassingYear());
		result.setResumeURL(saved.getResumeURL());

		return result;
	}

	public JobSeekerDTO getJobSeekerByEmail(String email) {
		Optional<JobSeeker> jobSeeker = jobSeekerRepository.findByEmail(email);

		return jobSeeker.map(jobSeek -> {
			JobSeekerDTO dto = new JobSeekerDTO();
			dto.setId(jobSeek.getId());
			dto.setName(jobSeek.getName());
			dto.setEmail(jobSeek.getEmail());
			dto.setPhone(jobSeek.getPhone());
			dto.setUniversityName(jobSeek.getUniversityName());
			dto.setCourse(jobSeek.getCourse());
			dto.setPassingYear(jobSeek.getPassingYear());
			dto.setResumeURL(jobSeek.getResumeURL());
			return dto;
		}).orElse(null);
	}
}
