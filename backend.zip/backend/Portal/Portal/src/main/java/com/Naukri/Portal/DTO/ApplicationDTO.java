package com.Naukri.Portal.DTO;

import java.time.LocalDateTime;

import com.Naukri.Portal.Enum.JobType;
import com.Naukri.Portal.Enum.Status;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ApplicationDTO {
	
	private String jobSeekerName;
	private String jobSeekerEmail;
	private Long jobId;
	private String jobTitle;
	private JobType jobType;
	private String recruiterEmail;
	private Status status;
	private LocalDateTime appliedAt;

}
